// Driver class for BankAccount to test its methods

public class BankAccountTester {
	
	public static void main(String[] args)
	{
		BankAccount myChecking = new BankAccount();
		myChecking.deposit(3500);
		
		System.out.println("Curent balance: $" + myChecking.getBalance());
		
		myChecking.withdraw(200.25);
		System.out.println("Curent balance: $" + myChecking.getBalance());
	}

}
