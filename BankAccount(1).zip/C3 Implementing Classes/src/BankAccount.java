// Implement a simple BankAccount class

public class BankAccount {
	
	private double balance; //instance variable
	
	//Constructor to initialize instance variable(s)
	public BankAccount()
	{
		balance = 0;
	}

	/**
	 * Deposits money into bank account
	 * @param amount the amount to be deposit
	 */
	public void deposit (double amount)
	{
		balance = balance + amount;
	}
	
	/**
	 * Withdraws money from the bank account
	 * @param amount the amount to be subtracted/withdrawn from account
	 */
	public void withdraw (double amount)
	{
		//if (amount > balance)
		if (amount > getBalance())
		balance = balance - amount;
	}
	
	/**
	 * Gets the current balance of the bank account
	 * @return the current balance
	 */
	public double getBalance()
	{
		return balance;
	}
}
